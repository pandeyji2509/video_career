//data is passed as props in video.js redered in videocomponenet.js
//to get any data pass it as props.data.(requirement)
//data is getting fetched from data.json in src/assets
import React,{useState} from 'react'
import './videoComponent.css';
import {BsFillPlayCircleFill} from "react-icons/bs";
import {AiOutlinePauseCircle} from "react-icons/ai"
function VideoComponent(props) {
  const[show,toggleshow]=useState(true);
  var vid = document.getElementById("myVideo");
  function pauseVid() {
    vid.pause();
  }
  function playVid() {
    vid.play();
  }
  return (
    <div className='outer-container'>
    <div className='inner-container'>
    <div className='overlay'>{props.data.company} | {props.data.position} </div>
    
      <video id="myVideo" className="video" type="video/mp4" src={props.data.video}  playsInline controls loop muted/>
          <p onClick={()=>toggleshow(!show)}>{show?<BsFillPlayCircleFill onClick={playVid} id="d"  className="btn" size={30}/>:<AiOutlinePauseCircle onClick={pauseVid} id="d"  className="btn" size={30}/>}</p>
          {show && null}
    </div>
    </div>
  )
}
export default VideoComponent;